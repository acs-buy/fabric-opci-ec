"""Types de donnees du moteur et table des comptes de difference d'estimation.

Les numeros de comptes proviennent du modele de plan de comptes de l'article
411-3 du recueil officiel des normes comptables de la gestion d'actifs, tome 2.
Aucun numero n'est saisi de memoire.

Contrainte de portabilite : ce module ne doit employer aucune syntaxe
posterieure a Python 3.11, les fonctions publiees de la plateforme tournant en
3.11 alors que le poste de developpement est en 3.12.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal


class NatureNonValorisable(Exception):
    """Levee lorsqu'une nature d'actif n'a pas de compte de difference d'estimation."""


# Stock de difference d'estimation, par nature d'actif.
# Article 411-3, classe 2, compte 27 et ses subdivisions.
COMPTE_DIFFERENCE_ESTIMATION = {
    "IMMEUBLE_LOCATIF": "271",
    "IMMOBILISATION_EN_COURS": "272",
    "AUTRE_DROIT_REEL": "273",
    "CREDIT_BAIL": "274",
    "AUTRE_ACTIF_IMMOBILIER": "276",
}

# Variation des differences d'estimation portee aux capitaux propres.
# Article 411-3, compte 105, subdivision 1052 pour la classe 2.
COMPTE_VARIATION_CLASSE_2 = "1052"


@dataclass(frozen=True)
class Actif:
    """Noyau commun de l'axe actif, toutes natures confondues."""

    code: str
    nature: str
    prix_de_revient: Decimal


@dataclass(frozen=True)
class Expertise:
    """Fait date, non referentiel. Alimente l'article 211-6, valeur actuelle."""

    code_actif: str
    date_valeur: date
    valeur_actuelle: Decimal


@dataclass(frozen=True)
class LigneEcriture:
    """Ligne d'ecriture. L'axe actif est porte a cote du compte, le format
    fiscal des 18 champs ne sachant pas le transporter."""

    compte: str
    debit: Decimal
    credit: Decimal
    code_actif: "str | None"
