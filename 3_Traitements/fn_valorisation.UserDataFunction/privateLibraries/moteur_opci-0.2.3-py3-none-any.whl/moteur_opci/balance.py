"""Lecture d'une balance de filiale et calcul de ses capitaux propres.

Une filiale fournit souvent une balance plutot qu'un fichier des ecritures.
Le calcul des capitaux propres est le critere B2 de la tranche T1, et il
alimente l'actif net reevalue de la filiale, cf. paragraphe 4.1 de la
specification.

DEUX PLANS DE COMPTES COHABITENT, ET CE MODULE NE LIT QUE LE SECOND.

1. L'OPCI tient ses comptes selon le modele de plan de comptes de l'article
   411-3 du reglement ANC n° 2021-09 relatif aux comptes annuels des
   organismes de placement collectif immobilier, modifie par le reglement
   ANC n° 2024-01. Sa classe 1, intitulee COMPTES DE CAPITAUX, ne comporte
   que quatre sous-classes : 10 capital et souscriptions, 11 reports a
   nouveau, 12 resultat, 19 regularisations. Aucun compte 15, 16, 17 ni 18
   n'y existe, les emprunts y relevant de la classe 5. A la cloture, les
   autres comptes de classe 1 concernant l'exercice sont vires au compte
   101 Capital en debut d'exercice.
2. Les filiales, societes de personnes ou societes de l'article L. 214-36
   du code monetaire et financier, tiennent leurs comptes selon le plan
   comptable general. C'est leur balance que ce module lit. Dans ce plan,
   la classe 1 contient aussi 15 provisions, 16 emprunts et dettes
   assimilees, 17 dettes rattachees a des participations et 18 comptes de
   liaison, dont aucun n'est un capital propre.

PERIMETRE DES CAPITAUX PROPRES, PAR INCLUSION ET NON PAR EXCLUSION.
Prefixes 10 a 14 du plan comptable general : capital et reserves, report a
nouveau, resultat de l'exercice, subventions d'investissement, provisions
reglementees. Le choix de l'inclusion est motive : une definition par
exclusion se degrade en silence des qu'un compte inattendu apparait, en le
rangeant du cote des capitaux propres, alors qu'une definition par
inclusion le laisse dehors et le signale, cf. comptes_classe_1_non_classes.
Ce filet est DISPONIBLE ET NON ENCORE TENDU : aucun appelant du dossier
n'invoque comptes_classe_1_non_classes hors des tests, faute d'appelant de
capitaux_propres lui-meme. Le brancher est une tache de la tranche T2, et
d'ici la le signalement est une capacite offerte, non un controle exerce.

RESERVE POUR T2. Si une filiale tenait sa balance au plan de comptes des
OPCI, le compte 105 Variation des differences d'estimation entrerait dans
le prefixe 10 et ferait double emploi avec les differences d'estimation de
l'etape 2 du paragraphe 4.1 de la specification. Ce module suppose donc une
balance tenue au plan comptable general, et une balance tenue a l'article
411-3 ne doit pas lui etre soumise sans arbitrage prealable.

CONVENTION DE SIGNE. Les capitaux propres sont rendus en valeur economique :
positifs quand l'entite en a. Une balance porte les capitaux propres au
credit, d'ou credit moins debit.
"""
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

ZERO = Decimal("0.00")

# La virgule n'est pas un separateur admis : elle est le separateur decimal
# des exports comptables francais, que _montant traite. Les accepter tous
# deux ferait glisser la partie decimale dans la colonne suivante et rendrait
# les montants tronques a leur partie entiere, sans autre signal que le
# controle d'equilibre, dont le motif designerait alors la mauvaise cause.
SEPARATEURS = (";", "\t", "|")
ENCODAGES = ("utf-8-sig", "cp1252", "iso-8859-15")

# Capitaux propres du plan comptable general, par inclusion.
PREFIXES_CAPITAUX_PROPRES = ("10", "11", "12", "13", "14")
# Comptes de classe 1 du plan comptable general qui ne sont pas des capitaux
# propres. La liste est documentaire : elle sert a motiver le signalement,
# jamais a decider de l'inclusion.
DETTES_DE_CLASSE_1 = {
    "15": "provisions",
    "16": "emprunts et dettes assimilees",
    "17": "dettes rattachees a des participations",
    "18": "comptes de liaison",
}
COLONNES_MINIMUM = 4


def _colonnes(n):
    """Accorde le nom en nombre. Le reviseur lit ces motifs."""
    return f"{n} colonne" if n <= 1 else f"{n} colonnes"


@dataclass(frozen=True)
class LigneBalance:
    compte: str
    libelle: str
    debit: Decimal
    credit: Decimal


def _lire_texte(chemin):
    """Rend le texte du fichier.

    LIMITE CONNUE. Les deux replis sont des codages a un octet : cp1252
    n'echoue que sur 5 octets non affectes, iso-8859-15 sur aucun. Un
    fichier reellement mal encode est donc lu avec des libelles brouilles
    plutot que refuse. Sans effet sur les montants, qui ne portent que des
    caracteres ASCII, mais ce repli n'est pas un controle d'encodage.
    """
    for enc in ENCODAGES:
        try:
            with open(chemin, encoding=enc) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    raise ValueError("aucun encodage connu ne permet de lire le fichier")


def _montant(valeur):
    brut = valeur.strip().replace(" ", "").replace("\xa0", "")
    return ZERO if not brut else Decimal(brut.replace(",", "."))


def _est_numero_de_compte(valeur):
    """Un numero de compte plausible porte au moins 3 chiffres ASCII en tete.

    CE PREDICAT EST UNE CONVENTION DE LECTURE, PAS UN DIAGNOSTIC. Il ecarte
    les lignes de titre et de sous-total, dont la premiere colonne porte un
    numero de classe seul ou un libelle, MAIS il ecarte aussi des vraies
    lignes de compte : une racine a 2 caracteres, usage courant d'une
    balance de synthese, et un compte alphanumerique. Ce qu'il rend faux
    n'est donc pas necessairement un sous-total, et aucun motif ne doit
    l'affirmer. Le test isascii n'est pas un ornement : isdigit est vrai des
    exposants et des chiffres pleine largeur, qu'aucune base ne
    reconnaitrait comme compte.
    """
    return (len(valeur) >= 3 and valeur[:3].isdigit()
            and valeur[:3].isascii())


def lire_balance(chemin):
    """Rend (lignes, erreurs). Une erreur est (numero_ligne, motif).

    Une erreur au numero de ligne 0 porte sur l'ensemble du fichier et non
    sur une ligne.

    La premiere ligne est exigee comme en-tete, et controlee : une balance
    dont l'en-tete manque perdrait sa premiere ligne comptable en silence.
    Toute ligne de donnees dont la premiere colonne n'est pas un numero de
    compte plausible est rejetee avec son motif, un sous-total compte sinon
    une seconde fois dans les capitaux propres.

    AUCUN CHEMIN DE CETTE FONCTION NE REND UNE LISTE VIDE SANS ERREUR. Si
    aucune ligne de donnees n'est retenue, une anomalie d'ensemble le dit et
    nomme ce qui n'a pas ete compris : sans elle, le controle d'equilibre
    comparait 0 a 0, se taisait, et capitaux_propres rendait 0,00 pour une
    balance que cette fonction n'avait tout simplement pas su lire. Un
    total nul et un total non calcule ne sont pas la meme chose.
    """
    brutes = [x for x in _lire_texte(chemin).splitlines() if x.strip()]
    if not brutes:
        return [], [(0, "fichier vide")]

    sep = max(SEPARATEURS, key=lambda s: brutes[0].count(s))
    entete = [c.strip() for c in brutes[0].split(sep)]
    if len(entete) < COLONNES_MINIMUM:
        return [], [(1, f"separateur indetermine : l'en-tete rend "
                        f"{_colonnes(len(entete))} pour {COLONNES_MINIMUM} "
                        f"attendues, avec les separateurs admis (point-virgule, "
                        f"tabulation, barre verticale)")]
    if _est_numero_de_compte(entete[0]):
        return [], [(1, "en-tete absent : la premiere ligne porte un numero "
                        "de compte au lieu du nom des colonnes")]

    lignes, erreurs, rejetees = [], [], []
    for i, brute in enumerate(brutes[1:], start=2):
        cases = [c.strip() for c in brute.split(sep)]
        if len(cases) != len(entete):
            rejetees.append(cases[0] if cases else "")
            erreurs.append((i, f"{_colonnes(len(cases))} au lieu de "
                               f"{len(entete)}"))
            continue
        if not _est_numero_de_compte(cases[0]):
            # LE MOTIF NE CONCLUT PAS SUR LA NATURE DE LA LIGNE. Il dit ce
            # qui n'a pas ete compris, et rien de plus : appeler sous-total
            # une vraie ligne de compte, dont la racine tient en 2
            # caracteres ou porte des lettres, envoyait le reviseur chercher
            # un defaut la ou il n'etait pas.
            rejetees.append(cases[0])
            erreurs.append((i, f"la premiere colonne, {cases[0]!r}, n'est pas "
                               f"un numero de compte reconnaissable : au "
                               f"moins 3 chiffres ASCII en tete sont "
                               f"attendus. Ligne non reprise"))
            continue
        try:
            lignes.append(LigneBalance(cases[0], cases[1],
                                       _montant(cases[2]),
                                       _montant(cases[3])))
        except InvalidOperation as e:
            rejetees.append(cases[0])
            erreurs.append((i, f"montant illisible : {e}"))

    # UNE BALANCE QUE CETTE FONCTION NE SAIT PAS LIRE NE REND JAMAIS ZERO.
    # Sans cette anomalie d'ensemble, une balance dont toutes les lignes de
    # donnees sont rejetees rendait une liste vide, le controle d'equilibre
    # comparait 0 a 0 et se taisait, capitaux_propres rendait 0,00, et ce
    # zero remontait a l'actif net reevalue de la filiale puis a la valeur
    # liquidative. Un total de capitaux propres nul et un total non calcule
    # ne sont pas la meme chose, et rien dans le resultat ne les distinguait.
    if not lignes:
        examinees = len(brutes) - 1
        apercu = ", ".join(repr(c) for c in rejetees[:5])
        detail = f" Premieres colonnes rencontrees : {apercu}." if apercu else ""
        erreurs.append((0,
            f"aucune ligne de donnees retenue sur {examinees} "
            f"{'ligne examinee' if examinees <= 1 else 'lignes examinees'} apres "
            f"l'en-tete : cette balance n'a pas ete comprise, et ses "
            f"capitaux propres ne sont pas nuls, ils ne sont pas calcules. "
            f"Separateur retenu : {sep!r}, en-tete lu : "
            f"{_colonnes(len(entete))}.{detail} Verifier le separateur, "
            f"l'ordre des colonnes et le format des numeros de compte"))
        return lignes, erreurs

    total_debit = sum((l.debit for l in lignes), ZERO)
    total_credit = sum((l.credit for l in lignes), ZERO)
    if total_debit != total_credit:
        erreurs.append((0, f"balance desequilibree : debit {total_debit}, "
                           f"credit {total_credit}"))
    return lignes, erreurs


def capitaux_propres(lignes):
    """Capitaux propres d'une balance tenue au plan comptable general.

    Somme des prefixes 10 a 14 en valeur economique, credit moins debit.
    Les 4 familles de classe 1 qui sont des dettes, 15 provisions, 16
    emprunts, 17 dettes rattachees a des participations et 18 comptes de
    liaison, sont hors du perimetre par construction, n'y figurant pas.
    """
    total = ZERO
    for l in lignes:
        if l.compte.startswith(PREFIXES_CAPITAUX_PROPRES):
            total += l.credit - l.debit
    return total


def comptes_classe_1_non_classes(lignes):
    """Rend les comptes de classe 1 exclus des capitaux propres, dans l'ordre.

    Contrepartie de la definition par inclusion : ce que capitaux_propres
    laisse dehors est nomme ici, de sorte qu'un plan de comptes inattendu se
    signale au lieu d'etre range par defaut d'un cote ou de l'autre. Les 4
    familles de dettes de classe 1 y figurent normalement ; tout autre
    compte de classe 1 y est un signal a instruire.

    A BRANCHER EN T2. Aucun appelant du dossier n'invoque cette fonction
    hors des tests : le filet est disponible, il n'est pas encore tendu, et
    il ne doit pas etre presente comme un controle exerce.
    """
    return [l.compte for l in lignes
            if l.compte.startswith("1")
            and not l.compte.startswith(PREFIXES_CAPITAUX_PROPRES)]
