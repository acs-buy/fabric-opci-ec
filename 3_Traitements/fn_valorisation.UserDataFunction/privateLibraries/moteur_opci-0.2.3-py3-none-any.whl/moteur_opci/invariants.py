"""Invariants du modele, verifies avant tout enregistrement.

L'invariant d'equilibre est egalement porte par un declencheur de la base, afin
qu'il ne depende pas de la discipline du code appelant. La verification faite
ici sert a interrompre le moteur avant l'ecriture, avec un message utile.
"""

from decimal import Decimal

from moteur_opci.modeles import LigneEcriture

ZERO = Decimal("0")


def lot_est_equilibre(lignes) -> bool:
    """Vrai si la somme des debits egale celle des credits.

    Un lot vide est equilibre par convention : l'absence d'ecart a ecrire n'est
    pas une anomalie.
    """
    lignes = list(lignes)
    total_debit = sum((ligne.debit for ligne in lignes), ZERO)
    total_credit = sum((ligne.credit for ligne in lignes), ZERO)
    return total_debit == total_credit


def total_debit(lignes) -> Decimal:
    return sum((ligne.debit for ligne in lignes), ZERO)


def total_credit(lignes) -> Decimal:
    return sum((ligne.credit for ligne in lignes), ZERO)
