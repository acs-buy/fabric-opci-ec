"""Moteur de valorisation OPCI.

Regles adossees au reglement ANC n° 2021-09, modifie par le reglement ANC
n° 2024-01, relatif aux comptes annuels des organismes de placement collectif
immobilier.
"""
