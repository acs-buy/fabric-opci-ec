"""Regle de difference d'estimation, article 211-9, ecrite en delta.

Mecanisme, identique pour toutes les natures d'actif : l'ecart entre la valeur
actuelle de l'article 211-6 et le prix de revient constitue une difference
d'estimation. Le stock est porte au compte 271 a 276 selon la nature, la
variation au compte 1052 pour la classe 2.

Les lots de valorisation sont des lots d'ecart et non de remplacement : ils
s'accumulent d'un arrete au suivant, ce qui impose de retrancher le stock deja
comptabilise.
"""

from decimal import Decimal

from moteur_opci.modeles import (
    COMPTE_DIFFERENCE_ESTIMATION,
    COMPTE_VARIATION_CLASSE_2,
    Actif,
    Expertise,
    LigneEcriture,
    NatureNonValorisable,
)

ZERO = Decimal("0")


def compte_difference_estimation(nature: str) -> str:
    """Compte de stock de difference d'estimation pour une nature d'actif.

    Leve NatureNonValorisable plutot que de retourner un compte par defaut :
    une nature inconnue est une anomalie de referentiel, pas un cas a absorber.
    """
    try:
        return COMPTE_DIFFERENCE_ESTIMATION[nature]
    except KeyError as absente:
        raise NatureNonValorisable(nature) from absente


def lignes_difference_estimation(
    actif: Actif,
    expertise: Expertise,
    stock_anterieur: Decimal = ZERO,
) -> list:
    """Lignes d'ecriture du delta de difference d'estimation d'un actif.

    Retourne une liste vide si le delta est nul : aucune ecriture sans mouvement.
    Le resultat est deterministe, ce qui est la condition de possibilite de la
    mesure de concordance.
    """
    compte_stock = compte_difference_estimation(actif.nature)
    ecart = expertise.valeur_actuelle - actif.prix_de_revient
    delta = ecart - stock_anterieur

    if delta == ZERO:
        return []

    if delta > ZERO:
        return [
            LigneEcriture(compte_stock, delta, ZERO, actif.code),
            LigneEcriture(COMPTE_VARIATION_CLASSE_2, ZERO, delta, actif.code),
        ]

    montant = -delta
    return [
        LigneEcriture(COMPTE_VARIATION_CLASSE_2, montant, ZERO, actif.code),
        LigneEcriture(compte_stock, ZERO, montant, actif.code),
    ]
