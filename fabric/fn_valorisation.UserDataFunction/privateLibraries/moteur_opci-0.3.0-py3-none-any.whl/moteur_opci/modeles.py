"""Types de donnees du moteur et table des comptes de difference d'estimation.

Les numeros de comptes proviennent du modele de plan de comptes de l'article
411-3 du recueil officiel des normes comptables de la gestion d'actifs, tome 2.
Aucun numero n'est saisi de memoire.

Contrainte de portabilite : ce module ne doit employer aucune syntaxe
posterieure a Python 3.11, les fonctions publiees de la plateforme tournant en
3.11 alors que le poste de developpement est en 3.12.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal


class NatureNonValorisable(Exception):
    """Levee lorsqu'un poste de bilan n'a pas de compte de difference d'estimation."""


# Stock de difference d'estimation, DERIVE du poste de bilan de l'actif et non
# de sa nature. Revu le 04/09/2026 : le module appariait par nature, avec un
# vocabulaire qui n'etait pas celui de dbo.ref_nature_actif, et la nature ne
# suffit pas. Un immeuble bati est au compte 213, un terrain au 211, tous deux
# sous le 21 et donc au 271 ; un immeuble en cours est au 221, donc au 272.
#
# La regle est lue sur piece dans le plan de comptes de l'article 411-3, les
# libelles s'appariant rang par rang : compte 21 « Immeubles locatifs » vers
# 271 « sur immeubles locatifs », 22 « Immobilisations en cours » vers 272,
# 23 « Autres droits reels » vers 273, 24 « Contrats de credit-bail » vers 274,
# 25 « Titres a caractere immobilier » vers 275, 26 « Autres actifs
# immobiliers » vers 276, et la classe 3 vers 37 « Differences d'estimation sur
# depots et instruments financiers et assimiles ».
#
# La base porte la meme regle dans dbo.fn_compte_difference_estimation : les 2
# implementations doivent rester identiques, et le test
# tests/test_concordance_compte_difference.py en est le garde-fou, poste par
# poste (10/10/2026).
COMPTE_DIFFERENCE_CLASSE_3 = "37"
RANGS_CLASSE_2 = ("1", "2", "3", "4", "5", "6")


def compte_difference_par_poste(poste_bilan: str) -> str:
    """Compte de stock de difference d'estimation pour un poste de bilan.

    Retourne None lorsque le poste ne releve ni de la classe 2 ni de la
    classe 3 : l'appelant decide s'il s'agit d'une anomalie.
    """
    if not poste_bilan:
        return None
    if poste_bilan[0] == "3":
        return COMPTE_DIFFERENCE_CLASSE_3
    if poste_bilan[0] == "2" and len(poste_bilan) >= 2:
        if poste_bilan[1] in RANGS_CLASSE_2:
            return "27" + poste_bilan[1]
    return None


# Contrepartie de la variation, portee aux capitaux propres. Reproduit
# dbo.ref_contrepartie_estimation, posee par le script 63_SQL/60. Les libelles
# du plan de comptes tranchent : le 1052 vise « les comptes d'immeubles en
# cours, construits ou acquis et des autres droits reels (classe 2) », le 1053
# « les depots et instruments financiers ». Ni l'un ni l'autre ne couvre les
# titres a caractere immobilier ni les autres actifs immobiliers : leur
# contrepartie est le compte 105 lui-meme, et pour le 276 l'article 213-4 le
# nomme expressement.
COMPTE_CONTREPARTIE_VARIATION = {
    "271": "1052",
    "272": "1052",
    "273": "1052",
    "274": "1052",
    "275": "105",
    "276": "105",
    "37": "1053",
}


@dataclass(frozen=True)
class Actif:
    """Noyau commun de l'axe actif, toutes natures confondues."""

    code: str
    nature: str
    prix_de_revient: Decimal
    # Le poste de bilan porte le compte de l'actif au sens de l'article
    # 321-2 : c'est lui qui determine le compte de difference d'estimation.
    poste_bilan: str = ""


@dataclass(frozen=True)
class Expertise:
    """Fait date, non referentiel. Alimente l'article 211-6, valeur actuelle."""

    code_actif: str
    date_valeur: date
    valeur_actuelle: Decimal


@dataclass(frozen=True)
class LigneEcriture:
    """Ligne d'ecriture. L'axe actif est porte a cote du compte, le format
    fiscal des 18 champs ne sachant pas le transporter."""

    compte: str
    debit: Decimal
    credit: Decimal
    code_actif: "str | None"
