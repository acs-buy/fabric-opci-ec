"""Regle de difference d'estimation, article 211-9, ecrite en delta.

Mecanisme, identique pour tous les actifs : l'ecart entre la valeur actuelle de
l'article 211-6 et le prix de revient constitue une difference d'estimation. Le
stock est porte au compte 271 a 276 pour la classe 2 et au compte 37 pour la
classe 3, DERIVE du poste de bilan de l'actif ; la variation va a la
contrepartie que dbo.ref_contrepartie_estimation prescrit, 1052 pour les
immeubles et droits reels, 105 pour les titres et les autres actifs
immobiliers, 1053 pour les depots et instruments financiers.

Les lots de valorisation sont des lots d'ecart et non de remplacement : ils
s'accumulent d'un arrete au suivant, ce qui impose de retrancher le stock deja
comptabilise.
"""

from decimal import Decimal

from moteur_opci.modeles import (
    COMPTE_CONTREPARTIE_VARIATION,
    Actif,
    Expertise,
    LigneEcriture,
    NatureNonValorisable,
    compte_difference_par_poste,
)

ZERO = Decimal("0")


def compte_difference_estimation(poste_bilan: str) -> str:
    """Compte de stock de difference d'estimation pour un poste de bilan.

    Leve NatureNonValorisable plutot que de retourner un compte par defaut :
    un poste hors classe 2 et hors classe 3 est une anomalie de referentiel,
    pas un cas a absorber.
    """
    compte = compte_difference_par_poste(poste_bilan)
    if compte is None:
        raise NatureNonValorisable(poste_bilan)
    return compte


def compte_contrepartie_variation(compte_stock: str) -> str:
    """Contrepartie aux capitaux propres du compte de stock donne.

    Leve NatureNonValorisable pour un compte sans contrepartie prescrite : la
    variation ne peut pas se porter a un compte choisi par defaut.
    """
    try:
        return COMPTE_CONTREPARTIE_VARIATION[compte_stock]
    except KeyError as absente:
        raise NatureNonValorisable(compte_stock) from absente


def lignes_difference_estimation(
    actif: Actif,
    expertise: Expertise,
    stock_anterieur: Decimal = ZERO,
) -> list:
    """Lignes d'ecriture du delta de difference d'estimation d'un actif.

    Retourne une liste vide si le delta est nul : aucune ecriture sans mouvement.
    Le resultat est deterministe, ce qui est la condition de possibilite de la
    mesure de concordance.
    """
    compte_stock = compte_difference_estimation(actif.poste_bilan)
    compte_variation = compte_contrepartie_variation(compte_stock)
    ecart = expertise.valeur_actuelle - actif.prix_de_revient
    delta = ecart - stock_anterieur

    if delta == ZERO:
        return []

    if delta > ZERO:
        return [
            LigneEcriture(compte_stock, delta, ZERO, actif.code),
            LigneEcriture(compte_variation, ZERO, delta, actif.code),
        ]

    montant = -delta
    return [
        LigneEcriture(compte_variation, montant, ZERO, actif.code),
        LigneEcriture(compte_stock, ZERO, montant, actif.code),
    ]
