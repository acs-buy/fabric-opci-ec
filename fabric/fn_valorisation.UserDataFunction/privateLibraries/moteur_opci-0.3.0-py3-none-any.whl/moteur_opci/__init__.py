"""Moteur de valorisation OPCI.

Regles adossees au reglement ANC n° 2021-09, modifie par le reglement ANC
n° 2024-01, relatif aux comptes annuels des organismes de placement collectif
immobilier.
"""

# Version des regles de difference d'estimation que porte chaque lot DERIVABLE ecrit
# par fn_valorisation quand l'appel ne la donne pas (ck_version_si_derivable ;
# lot_ecritures.version_regles, VARCHAR (20)). Elle suit la regle et non chaque
# publication : la roue 0.3.0 est la premiere qui derive le compte de difference
# du poste du bilan de l'actif (modeles.compte_difference_par_poste).
VERSION_REGLES = "poste-bilan-0.3.0"
