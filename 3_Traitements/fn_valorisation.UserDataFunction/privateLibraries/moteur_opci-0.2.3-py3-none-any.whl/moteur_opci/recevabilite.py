"""Controles de recevabilite d'un fichier des ecritures comptables.

Ce module ne connait pas la base de donnees. Il recoit des lignes typees et
rend des verdicts motives : le critere B1 de la tranche T1 exige qu'aucune
ecriture ne soit rejetee sans motif trace.

Deux contraintes de la base sont controlees en amont, pour que le rejet
porte un motif lisible plutot qu'une violation de contrainte :
  ck_sens_unique     : debit a zero OU credit a zero
  ck_montant_positif : les 2 montants sont positifs ou nuls

L'echelle decimale des colonnes de montant de la table de transit n'est pas
uniforme, cf. ECHELLES_MONTANT : 2 decimales au debit et au credit,
3 decimales au montant en devise. Le controle porte sur la perte reelle de
precision et non sur le nombre de decimales ecrites.

L'ORDRE DES CONTROLES DE controler_ligne EST SIGNIFICATIF, et verrouille par
des tests. Il est le suivant, et aucun controle ne se deplace : prefixe de
compte, longueur, echelle decimale, signe, sens unique, deux montants nuls,
date de comptabilisation, hors exercice, date de validation. Le motif rendu
est celui du premier controle qui echoue : l'ordre decide donc du motif que
lira le comptable, et un motif de niveau inferieur en masquerait un plus
fondamental. L'echelle decimale precede le signe parce qu'un montant NaN
franchirait le signe comme le sens unique, toute comparaison avec lui etant
fausse.
"""
from dataclasses import dataclass
from decimal import (Decimal, InvalidOperation, ROUND_HALF_UP,
                     localcontext)

from .fec import CHAMPS_MONTANT

ZERO = Decimal("0.00")

# Longueurs maximales des colonnes du transit (dbo.stg_fec, cf.
# 63_SQL/10_transit_et_rattachement.sql). Un champ qui les depasse ferait
# echouer la copie entiere vers la base au lieu de produire un rejet
# motive : ce controle protege le critere B1 (aucune ecriture rejetee sans
# motif trace) en amont de la base.
#
# Les 11 entrees sont les 11 colonnes texte bornees que le transit alimente
# depuis le fichier des ecritures, relevees une par une sur la definition de
# la table, partie 1 du script 10. Les 4 champs de date et les 3
# champs de montant n'ont pas d'entree ici : leur type les borne, et
# l'echelle decimale des montants est controlee a part, ECHELLES_MONTANT.
LONGUEURS_MAX = {
    "JournalCode": 10,
    "JournalLib": 100,
    "EcritureNum": 30,
    "CompteNum": 20,
    "CompteLib": 200,
    "CompAuxNum": 20,
    "CompAuxLib": 200,
    "PieceRef": 50,
    "EcritureLib": 400,
    "EcritureLet": 40,
    "Idevise": 3,
}

# Echelle decimale des colonnes de montant du transit, relevee sur la
# definition de dbo.stg_fec (63_SQL/10_transit_et_rattachement.sql).
#
# LES ECHELLES NE SONT PAS UNIFORMES, ET C'EST VOULU.
#   debit et credit     DECIMAL(19, 2). L'euro porte 2 decimales, et les
#                       colonnes de contrepartie de dbo.ecriture aussi.
#   montant_devise      DECIMAL(19, 3). L'article A47 A-1 du livre des
#                       procedures fiscales attend le montant dans la
#                       DEVISE D'ORIGINE, et les monnaies a 3 decimales
#                       existent : dinar tunisien TND, dinar koweitien KWD,
#                       dinar bahreini BHD. Borner cette colonne a 2
#                       decimales n'etait pas un controle, c'etait une
#                       contrainte de schema trop etroite, qui faisait
#                       tomber une ligne par ailleurs impeccable et, la
#                       ligne tombant, desequilibrait le lot entier.
#
# CE QUE LE CONTROLE TESTE, ET CE QU'IL NE TESTE PAS. Il teste la PERTE
# REELLE DE PRECISION, jamais le nombre de decimales ecrites : la valeur est
# arrondie a l'echelle de destination et comparee a la valeur d'origine, et
# elle ne passe que si les deux sont egales. Un export a 3 decimales dont la
# troisieme est nulle, 1000,000, est exactement representable en
# DECIMAL(19, 2) : le refuser au motif de son exposant declare arretait
# l'import entier d'un fichier parfaitement valide, avec un motif affirmant
# faussement que le montant serait arrondi. Une garde se specifie par ce
# qu'elle doit laisser passer, pas seulement par ce qu'elle doit refuser.
#
# Le controle reste a l'amont, ou le decimal exact est encore disponible :
# sans lui, un montant reellement plus precis serait arrondi en silence par
# la conversion vers la plateforme, et soit les montants charges ne seraient
# plus ceux du fichier, soit l'arrondi desequilibrerait le lot et le
# declencheur leverait 50001 sans que rien n'en designe la cause.
ECHELLES_MONTANT = {
    "Debit": 2,
    "Credit": 2,
    "Montantdevise": 3,
}
# Precision totale des colonnes DECIMAL(19, x) du transit. Elle borne aussi
# l'arrondi de controle : une valeur qui n'entre pas dans 19 chiffres
# significatifs ne rentre pas dans la colonne, et le dire ici vaut mieux que
# de laisser la base lever une erreur de conversion sans motif trace.
PRECISION_MONTANT = 19


def arrondi_a_l_echelle(valeur, echelle):
    """Rend la valeur telle que la colonne de destination la porterait.

    Rend None si elle n'y tient pas du tout, faute de precision totale.
    L'arrondi est ROUND_HALF_UP, celui du moteur de la base, de sorte que la
    valeur nommee dans le motif soit celle que le comptable retrouverait.
    """
    with localcontext() as ctx:
        ctx.prec = PRECISION_MONTANT
        ctx.rounding = ROUND_HALF_UP
        try:
            return valeur.quantize(Decimal(1).scaleb(-echelle))
        except InvalidOperation:
            return None


@dataclass(frozen=True)
class Verdict:
    numero_ligne: int
    recevable: bool
    motif: str


def controler_ligne(ligne, exercice_debut, exercice_fin):
    """Rend le premier motif de rejet rencontre, ou un verdict recevable."""
    # isdigit seul est vrai des chiffres non ASCII, exposants et chiffres
    # pleine largeur compris, qu'aucune base ne reconnaitrait comme compte.
    if len(ligne.CompteNum) < 3 or not (ligne.CompteNum[:3].isdigit()
                                        and ligne.CompteNum[:3].isascii()):
        return Verdict(ligne.numero_ligne, False,
                       "les trois premiers caracteres du compte doivent "
                       "etre des chiffres ASCII, art. A47 A-1")
    for champ, longueur_max in LONGUEURS_MAX.items():
        valeur = getattr(ligne, champ)
        if valeur is not None and len(valeur) > longueur_max:
            return Verdict(ligne.numero_ligne, False,
                           f"{champ} depasse la longueur maximale : "
                           f"{len(valeur)} caracteres pour {longueur_max} "
                           f"autorises")
    for champ in CHAMPS_MONTANT:
        valeur = getattr(ligne, champ)
        if valeur is None:
            continue
        if not valeur.is_finite():
            return Verdict(ligne.numero_ligne, False,
                           f"{champ} n'est pas un montant fini : une valeur "
                           f"NaN ou infinie franchirait les controles de "
                           f"signe et de sens, toute comparaison avec elle "
                           f"etant fausse")
        echelle = ECHELLES_MONTANT[champ]
        arrondi = arrondi_a_l_echelle(valeur, echelle)
        if arrondi is None:
            return Verdict(ligne.numero_ligne, False,
                           f"{champ} excede la capacite de la colonne de "
                           f"destination, DECIMAL({PRECISION_MONTANT}, "
                           f"{echelle}) : {valeur} n'y tient pas, echelle "
                           f"decimale comprise")
        if arrondi != valeur:
            return Verdict(ligne.numero_ligne, False,
                           f"{champ} perdrait de la precision a la "
                           f"conversion vers l'echelle decimale de la "
                           f"colonne de destination, DECIMAL("
                           f"{PRECISION_MONTANT}, {echelle}) : {valeur} "
                           f"deviendrait {arrondi}")
    if ligne.Debit < ZERO or ligne.Credit < ZERO:
        return Verdict(ligne.numero_ligne, False,
                       "montant negatif : le sens est porte par la colonne, "
                       "jamais par le signe")
    if ligne.Debit != ZERO and ligne.Credit != ZERO:
        return Verdict(ligne.numero_ligne, False,
                       "une ecriture porte un seul sens, debit ou credit")
    if ligne.Debit == ZERO and ligne.Credit == ZERO:
        return Verdict(ligne.numero_ligne, False, "aucun montant, ni au debit ni au credit")
    if ligne.EcritureDate is None:
        return Verdict(ligne.numero_ligne, False, "date de comptabilisation "
                                                  "absente")
    if not exercice_debut <= ligne.EcritureDate <= exercice_fin:
        return Verdict(ligne.numero_ligne, False,
                       f"date de comptabilisation hors exercice : "
                       f"{ligne.EcritureDate}")
    if ligne.ValidDate is None:
        return Verdict(ligne.numero_ligne, False,
                       "date de validation absente, champ 16 obligatoire")
    return Verdict(ligne.numero_ligne, True, "")


def controler_lot(lignes, exercice_debut, exercice_fin):
    """Rend (verdicts, anomalies d'ensemble)."""
    verdicts = [controler_ligne(l, exercice_debut, exercice_fin)
                for l in lignes]
    recevables = [l for l, v in zip(lignes, verdicts) if v.recevable]
    anomalies = []
    total_debit = sum((l.Debit for l in recevables), ZERO)
    total_credit = sum((l.Credit for l in recevables), ZERO)
    if total_debit != total_credit:
        ecart = abs(total_debit - total_credit)
        anomalies.append(
            f"lot desequilibre : debit {total_debit}, credit {total_credit}, "
            f"ecart {ecart}")
    return verdicts, anomalies
