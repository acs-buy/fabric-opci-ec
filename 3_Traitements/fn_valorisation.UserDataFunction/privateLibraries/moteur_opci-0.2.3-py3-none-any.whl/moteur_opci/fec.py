"""Lecture d'un fichier des ecritures comptables.

Article A47 A-1 du livre des procedures fiscales : les zones d'un fichier a
plat sont separees par une tabulation ou le caractere barre verticale, et la
premiere ligne porte le nom des champs.

Ce module ne connait ni base de donnees ni metier : il lit, il type, il
signale les erreurs de forme. Les controles de recevabilite sont ailleurs.
"""
from dataclasses import dataclass
from datetime import date, datetime
import unicodedata
from decimal import Decimal, InvalidOperation

CHAMPS_FEC = (
    "JournalCode", "JournalLib", "EcritureNum", "EcritureDate",
    "CompteNum", "CompteLib", "CompAuxNum", "CompAuxLib",
    "PieceRef", "PieceDate", "EcritureLib", "Debit", "Credit",
    "EcritureLet", "DateLet", "ValidDate", "Montantdevise", "Idevise",
)

CHAMPS_DATE = ("EcritureDate", "PieceDate", "DateLet", "ValidDate")
CHAMPS_MONTANT = ("Debit", "Credit", "Montantdevise")

ENCODAGES = ("utf-8-sig", "cp1252", "iso-8859-15")


@dataclass(frozen=True)
class LigneFec:
    numero_ligne: int
    JournalCode: str
    JournalLib: str
    EcritureNum: str
    EcritureDate: "date | None"
    CompteNum: str
    CompteLib: str
    CompAuxNum: str
    CompAuxLib: str
    PieceRef: str
    PieceDate: "date | None"
    EcritureLib: str
    Debit: Decimal
    Credit: Decimal
    EcritureLet: str
    DateLet: "date | None"
    ValidDate: "date | None"
    Montantdevise: "Decimal | None"
    Idevise: str


SEPARATEURS = ("\t", "|")


def detecter_separateur(entete):
    """Rend le separateur de l'en-tete, choisi par decompte.

    Le choix se fait sur le nombre d'occurrences et non sur la presence :
    un fichier a barre verticale portant une seule tabulation, de fin de
    ligne ou de mise en forme, etait sinon lu comme un fichier a
    tabulations, donc declare non conforme a l'article A47 A-1 alors que
    son en-tete l'est. L'en-tete est en outre nettoye de ses blancs de fin
    avant le decompte, une tabulation terminale ne designant aucune colonne.
    Tabulation en cas d'egalite, y compris quand aucun des 2 separateurs
    n'est present, cas que separateur_indetermine reconnait a part pour que
    le motif de rejet ne mente pas.
    """
    return max(SEPARATEURS, key=entete.rstrip().count)


def separateur_indetermine(entete):
    """Vrai si l'en-tete ne porte aucun des 2 separateurs de l'article."""
    return all(s not in entete.rstrip() for s in SEPARATEURS)


def _lire_texte(chemin):
    """Rend le texte du fichier.

    LIMITE CONNUE. Les 2 replis sont des codages a un octet : cp1252
    n'echoue que sur 5 octets non affectes, iso-8859-15 sur aucun. Un
    fichier reellement mal encode est donc lu avec des libelles brouilles
    plutot que refuse. Sans effet sur les montants ni sur les dates, qui ne
    portent que des caracteres ASCII, mais ce repli n'est pas un controle
    d'encodage et ne doit pas etre presente comme tel.
    """
    for enc in ENCODAGES:
        try:
            with open(chemin, encoding=enc) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    raise ValueError("aucun encodage connu ne permet de lire le fichier")


def _date(valeur):
    if not valeur.strip():
        return None
    return datetime.strptime(valeur.strip(), "%Y%m%d").date()


def _montant(valeur):
    # La premiere substitution retire l'espace ordinaire, la seconde
    # l'espace insecable (U+00A0), separateur de milliers usuel des
    # exports comptables francais. Les deux especes sont distinctes,
    # aucune des deux substitutions n'est redondante.
    brut = valeur.strip().replace(" ", "").replace("\xa0", "")
    if not brut:
        return None
    return Decimal(brut.replace(",", "."))


TOLERANCE_ENTETE = 1
"""Distance d'edition maximale toleree sur un nom de champ de l'en-tete.

Ce seuil n'est pas un choix de confort, il est borne par une propriete du jeu de
champs de l'article A47 A-1 : la distance minimale entre 2 noms canonises vaut 2,
entre `EcritureLib` et `EcritureLet`. Un seuil de 1, applique position par
position, accepte donc une faute de frappe et refuse toute permutation de 2
champs, chaque nom permute se trouvant a distance 2 de celui attendu a sa place.
Le test `test_le_seuil_est_strictement_inferieur_a_la_distance_minimale` verrouille
cette propriete : si le jeu de champs change, il echoue.
"""


def canoniser(nom):
    """Rend un nom de champ comparable : sans accent, sans casse, sans separateur."""
    plat = unicodedata.normalize("NFKD", nom).encode("ascii", "ignore").decode()
    return "".join(c for c in plat.lower() if c.isalnum())


def distance_edition(a, b):
    """Distance de Levenshtein, sans dependance externe."""
    if len(a) < len(b):
        a, b = b, a
    precedent = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        courant = [i]
        for j, cb in enumerate(b, 1):
            courant.append(min(precedent[j] + 1,
                               courant[j - 1] + 1,
                               precedent[j - 1] + (ca != cb)))
        precedent = courant
    return precedent[-1]


def lire_fec(chemin):
    """Rend (lignes, erreurs). Une erreur est (numero_ligne, motif).

    Une ligne portant plus de 18 champs n'est pas signalee : l'article A47 A-1
    prescrit que le fichier porte toutes les donnees comptables de
    l'entreprise, les 18 premieres correspondant dans l'ordre a la liste des
    champs, les eventuels champs suivants sont donc licites et ignores ici.
    """
    texte = _lire_texte(chemin)
    brutes = [x for x in texte.splitlines() if x.strip()]
    if not brutes:
        return [], [(0, "fichier vide")]

    if separateur_indetermine(brutes[0]):
        return [], [(1, "separateur indetermine : l'article A47 A-1 prescrit "
                        "la tabulation ou la barre verticale, l'en-tete ne "
                        "porte ni l'une ni l'autre")]
    sep = detecter_separateur(brutes[0])
    entete = [c.strip() for c in brutes[0].split(sep)]
    if len(entete) < 18:
        return [], [(1, "en-tete a %d champs au lieu de 18, article A47 A-1"
                        % len(entete))]

    lignes, erreurs = [], []
    for attendu, lu in zip(CHAMPS_FEC, entete[:18]):
        if canoniser(lu) == canoniser(attendu):
            continue
        if distance_edition(canoniser(lu), canoniser(attendu)) <= TOLERANCE_ENTETE:
            erreurs.append((1, "en-tete tolere : le champ lu « %s » differe du "
                               "champ « %s » de l'article A47 A-1, la lecture se "
                               "fait sur la position" % (lu, attendu)))
            continue
        return [], [(1, "en-tete non conforme a l'article A47 A-1 : le champ lu "
                        "« %s » ne correspond pas au champ « %s » attendu a cette "
                        "position" % (lu, attendu))]

    for i, brute in enumerate(brutes[1:], start=2):
        cases = brute.split(sep)
        if len(cases) < 18:
            erreurs.append((i, f"{len(cases)} champs au lieu de 18"))
            continue
        valeurs = {}
        ligne_illisible = False
        for nom, brut in zip(CHAMPS_FEC, cases[:18]):
            try:
                if nom in CHAMPS_DATE:
                    valeurs[nom] = _date(brut)
                elif nom in CHAMPS_MONTANT:
                    m = _montant(brut)
                    valeurs[nom] = (
                        Decimal("0.00") if m is None and nom != "Montantdevise"
                        else m)
                else:
                    valeurs[nom] = brut.strip()
            except (ValueError, InvalidOperation) as e:
                erreurs.append((i, f"champ {nom} illisible : {e}"))
                ligne_illisible = True
                break
        if ligne_illisible:
            continue
        lignes.append(LigneFec(numero_ligne=i, **valeurs))
    return lignes, erreurs
